
import 'package:flutter/material.dart';

void main() {
  runApp(const IAeditApp());
}

class IAeditApp extends StatelessWidget {
  const IAeditApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'IAedit',
      home: Scaffold(
        appBar: AppBar(title: const Text('IAedit')),
        body: const Center(
          child: Text('IAedit – versão de teste'),
        ),
      ),
    );
  }
}
